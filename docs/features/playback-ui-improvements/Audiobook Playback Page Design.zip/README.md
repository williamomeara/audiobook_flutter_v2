
  # Audiobook Playback Page Design

  This is a code bundle for Audiobook Playback Page Design. The original project is available at https://www.figma.com/design/QxaYv83kidvBrbD7UrZavl/Audiobook-Playback-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  