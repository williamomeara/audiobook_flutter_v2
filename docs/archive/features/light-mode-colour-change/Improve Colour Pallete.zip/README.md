
  # Improve Book Detail and Library Pages

  This is a code bundle for Improve Book Detail and Library Pages. The original project is available at https://www.figma.com/design/L4RUGqa3QyEtH5yG7cvmUy/Improve-Book-Detail-and-Library-Pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  